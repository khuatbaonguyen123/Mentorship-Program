import java.util.Random;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class App {

    static Scanner scanner = new Scanner(System.in);
    static Random rand = new Random();

    public static void main(String[] args) throws Exception {
        //Get the size of the array from user
        System.out.print("Enter the size of the array (n): ");
        int n = scanner.nextInt();

        int[] a = new int[n];

        generateRandomArray(a);

        System.out.print("Elements of the array: ");
        printArray(a);

        findAndPrintMostFrequentElement(a);
    }

    public static void generateRandomArray(int[] a) {
        int n = a.length;
        for(int i = 0; i < n; ++i) {
            a[i] = rand.nextInt(10);
        }
    }

    public static void printArray(int[] a) {
        int n = a.length;
        for(int i = 0; i < n; ++i) {
            System.out.print(a[i] + " ");
        }
        System.out.print("\n");
    }

    public static void findAndPrintMostFrequentElement(int[] a) {
        HashMap<Integer, Integer> frequencyMap = new HashMap<>();
        for (int num : a) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        int maxCount = frequencyMap.get(a[0]);

        for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
            }
        }

        System.out.print("The most frequent elements are: ");

        for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
            if (entry.getValue() == maxCount) {
                System.out.print(entry.getKey() + " ");
            }
        }
    }

}
