import java.util.Random;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static Random rand = new Random();
    public static void main(String[] args) throws Exception {
        //Get the size of the array from user
        System.out.print("Enter the size of the array (n): ");
        int n = readInteger();

        int[] arr = new int[n];
        generateRandomArray(arr);

        System.out.print("Elements of the array: ");
        printArray(arr);

        System.out.print("Enter the position to delete: ");
        int pos = inputPos(n);

        arr = deleteElement(arr, pos);

        printArray(arr);
    }

    // Make sure the input is integer
    private static int readInteger() {
        while(!scanner.hasNextInt()) {
            System.out.print("Invalid input. Enter again: ");
            scanner.nextLine();
        }

        return scanner.nextInt();
    } 

    // Make sure the position is valid
    private static int inputPos(int arrayLength) {
        int pos = readInteger();

        while(pos < 0 || pos > arrayLength - 1) {
            System.out.print("Invalid input. Enter again: ");
            pos = readInteger();
        }

        return pos;
    }

    // Generate random array with each element ranging from 0 to 9
    private static void generateRandomArray(int[] a) {
        int n = a.length;
        for(int i = 0; i < n; ++i) {
            a[i] = rand.nextInt(10);
        }
    }

    // Print the array
    private static void printArray(int[] a) {
        int n = a.length;
        for(int i = 0; i < n; ++i) {
            System.out.print(a[i] + " ");
        }
        System.out.print("\n");
    }

    // Return the new array with the element deleted at the given position
    private static int[] deleteElement(int[] arr, int pos) {
        int n = arr.length;
        int[] newArr = new int[n - 1];

        for(int i = 0; i < pos; ++i) {
            newArr[i] = arr[i];
        }

        for(int i = pos; i < n - 1; ++i) {
            newArr[i] = arr[i + 1];
        }

        return newArr;
    }
}
